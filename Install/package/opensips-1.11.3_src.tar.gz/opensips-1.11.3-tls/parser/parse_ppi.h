/*
 *
 * Copyright (C) 2006 Juha Heinanen
 *
 * This file is part of opensips, a free SIP server.
 *
 * opensips is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version
 *
 * opensips is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


#ifndef PARSE_PPI_H
#define PARSE_PPI_H

#include "msg_parser.h"


/* casting macro for accessing P-Preferred-Identity body */
#define get_ppi(p_msg)  ((struct to_body*)(p_msg)->ppi->parsed)


/*
 * P-Preferred-Identity header field parser
 */
int parse_ppi_header( struct sip_msg *msg);

struct sip_uri *parse_ppi_uri(struct sip_msg *msg);

#endif /* PARSE_PPI_H */

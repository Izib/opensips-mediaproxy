# Copyright (C) 2008-2014 AG-Projects.
#

"""Interfaces between Mediaproxy and the other components in the system"""

